<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Goldsalesfatafat</strong>. All Rights Reserved
        </p>
        
      </div>
    </footer>