<?php
include_once ("../functions.php");

$obj = new Register;

extract($_REQUEST);
if (isset($save)) {
    $obj->insert($_REQUEST);
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body>
    <center><u><h4>ADD PRODUCT</h4></u></center>
    <form method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="form-group col-md-3">
                <label>Product Name</label>
                <input type="text" class="form-control" name="pname">
            </div>
             <div class="form-group col-md-3">
                <label>Is in stock <br />
                    <input type="checkbox" value="1"   name="in_stock" />
                </label>
            </div>
            <div class="form-group col-md-2">
                <label>Is Booking Open <br />
                    <input type="checkbox" value="1"   name="is_booking" />

                </label>
            </div>
            <div class="form-group col-md-2">
                <label>Booking Open Time   </label>
                <input type="text" class="form-control" name="b_open" placeholder="Booking Open Time" value="" />
            </div>
            <div class="form-group col-md-2">
                <label>Booking Close Time   </label>
                <input type="text" class="form-control" name="b_close" placeholder="Booking Close Time" value="" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label>Phone</label>
                <input type="text" placeholder="Phone Number" class="form-control" name="phone_no">	
            </div>
            <div class="form-group col-md-6">
                <label>Condition</label>
                <input type="text" class="form-control" name="cond">	
            </div>
            <div class="form-group col-md-6">
                <label>Selling Price</label>
                <input type="text" class="form-control" name="sp">	
            </div>
            <div class="form-group col-md-6">
                <label>Actual Selling Price</label>
                <input type="text" class="form-control" name="asp">	
            </div>
            <div class="form-group col-md-6">
                <label>Quantity</label>
                <input type="text" class="form-control" name="q1">	
            </div>
            <div class="form-group col-md-6">
                <label>Offer Price</label>
                <input type="text" class="form-control" name="op">	
            </div>
            <div class="form-group col-md-6">
                <label>Quantity</label>
                <input type="text" class="form-control" name="q2">	
            </div>
            <div class="form-group col-md-6">
                <label>Description</label>
                <input type="text" class="form-control" name="desc">	
            </div>
            <div class="form-group col-md-6">
                <label>Metal Details</label>
                <textarea class="form-control" name="md"></textarea>
                <script>
                    CKEDITOR.replace('md');
                </script>	
            </div>
            <div class="form-group col-md-6">
                <label>Product Info</label>
                <textarea class="form-control" name="pi"></textarea>
                <script>
                    CKEDITOR.replace('pi');
                </script>	
            </div>
            <div class="form-group col-md-6">
                <label>Diamond Info</label>
                <textarea class="form-control" name="di"></textarea>
                <script>
                    CKEDITOR.replace('di');
                </script>	
            </div>
            <div class="form-group col-md-6">
                <label>Services</label>
                <textarea class="form-control" name="ser"></textarea>
                <script>
                    CKEDITOR.replace('ser');
                </script>	
            </div>

            <div class="form-group col-md-6">
                <label>ADD IMAGES (SQUARE IMAGE)</label><br>
                <div id="filediv"><input name="file[]" type="file" id="file"/></div>
                <input type="button" id="add_more" class="upload btn-xs btn-info" value="Add More Files"/>
            </div>

            <input type="submit" name="save" value="SUBMIT">
        </div>
    </form>
</body>
</html>